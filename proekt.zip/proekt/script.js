// ========== КОНФИГУРАЦИЯ ==========
// 🔁 ЗДЕСЬ УКАЖИТЕ ВАШ URL СЕРВЕРА ИЗ ДНЯ 4!
const SERVER_URL = "https://ваш-проект.ваш-username.repl.co";  // 👈 ЗАМЕНИТЕ!

// ========== ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ==========
let currentWorks = [];
let currentFilter = "all";
let currentModalIndex = 0;

// ========== УПРАВЛЕНИЕ СПИННЕРОМ ==========
function showLoader() {
    const loader = document.getElementById("loader");
    const gallery = document.getElementById("gallery");
    if (loader) loader.classList.remove("hidden");
    if (gallery) gallery.style.display = "none";
}

function hideLoader() {
    const loader = document.getElementById("loader");
    const gallery = document.getElementById("gallery");
    if (loader) loader.classList.add("hidden");
    if (gallery) gallery.style.display = "grid";
}

// ========== ЗАГРУЗКА ДАННЫХ С СЕРВЕРА ==========
async function loadWorksFromServer() {
    showLoader();
    
    try {
        const response = await fetch(`${SERVER_URL}/api/works`);
        if (!response.ok) throw new Error("Ошибка загрузки");
        currentWorks = await response.json();
        renderGallery();
    } catch (error) {
        console.error("Ошибка:", error);
        // fallback на случай, если сервер не доступен
        currentWorks = [
            { id: 1, title: "Городской ритм", category: "улица", imageUrl: "https://picsum.photos/id/104/400/300", description: "Ночной мегаполис в движении. Длинная выдержка и огни города создают атмосферу." },
            { id: 2, title: "Отражение", category: "портрет", imageUrl: "https://picsum.photos/id/64/400/300", description: "Портрет с естественным светом. Пойман момент искренности." },
            { id: 3, title: "Тишина леса", category: "пейзаж", imageUrl: "https://picsum.photos/id/15/400/300", description: "Утренний туман над соснами. Природа просыпается." },
            { id: 4, title: "Уличный музыкант", category: "улица", imageUrl: "https://picsum.photos/id/345/400/300", description: "Момент вдохновения на городской улице." },
            { id: 5, title: "Взгляд", category: "портрет", imageUrl: "https://picsum.photos/id/169/400/300", description: "Эмоциональный портрет, передающий характер." },
            { id: 6, title: "Закат на озере", category: "пейзаж", imageUrl: "https://picsum.photos/id/30/400/300", description: "Золотой час над водой. Спокойствие и красота." }
        ];
        renderGallery();
    } finally {
        hideLoader();
    }
}

// ========== ОТРИСОВКА ГАЛЕРЕИ ==========
function renderGallery() {
    const gallery = document.getElementById("gallery");
    if (!gallery) return;
    
    let filtered = currentWorks;
    if (currentFilter !== "all") {
        filtered = currentWorks.filter(work => work.category === currentFilter);
    }
    
    if (filtered.length === 0) {
        gallery.innerHTML = '<p style="text-align:center; grid-column:1/-1; padding: 2rem;">😕 Нет работ в этой категории</p>';
        return;
    }
    
    gallery.innerHTML = filtered.map((work, index) => `
        <div class="card" data-id="${work.id}" data-index="${index}">
            <img src="${work.imageUrl}" alt="${work.title}" loading="lazy">
            <h3>${escapeHtml(work.title)}</h3>
            <p>${escapeHtml(work.description.substring(0, 80))}${work.description.length > 80 ? '...' : ''}</p>
            <span class="category">${escapeHtml(work.category)}</span>
        </div>
    `).join("");
    
    // Добавляем обработчики на карточки
    document.querySelectorAll('.card').forEach(card => {
        card.addEventListener('click', (e) => {
            const idx = parseInt(card.dataset.index);
            openModal(idx);
        });
    });
}

// Защита от XSS
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

// ========== МОДАЛЬНОЕ ОКНО ==========
function getFilteredWorks() {
    return currentFilter === "all" 
        ? currentWorks 
        : currentWorks.filter(w => w.category === currentFilter);
}

function openModal(index) {
    const filtered = getFilteredWorks();
    if (index < 0) index = 0;
    if (index >= filtered.length) index = filtered.length - 1;
    
    currentModalIndex = index;
    const work = filtered[currentModalIndex];
    
    const modal = document.getElementById("modal");
    const modalImg = document.getElementById("modal-img");
    const modalTitle = document.getElementById("modal-title");
    const modalDesc = document.getElementById("modal-desc");
    
    if (modalImg) modalImg.src = work.imageUrl;
    if (modalTitle) modalTitle.textContent = work.title;
    if (modalDesc) modalDesc.textContent = work.description;
    
    if (modal) modal.classList.remove("hidden");
    document.body.style.overflow = "hidden"; // запрещаем скролл фона
}

function closeModal() {
    const modal = document.getElementById("modal");
    if (modal) modal.classList.add("hidden");
    document.body.style.overflow = "auto"; // возвращаем скролл
}

function nextImage() {
    const filtered = getFilteredWorks();
    if (currentModalIndex + 1 < filtered.length) {
        openModal(currentModalIndex + 1);
    }
}

function prevImage() {
    if (currentModalIndex - 1 >= 0) {
        openModal(currentModalIndex - 1);
    }
}

// ========== ОТПРАВКА ФОРМЫ НА СЕРВЕР ==========
async function sendMessage(name, email, message) {
    try {
        const response = await fetch(`${SERVER_URL}/api/message`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, text: message })
        });
        
        const result = await response.json();
        
        if (response.ok && result.status === "ok") {
            return { success: true };
        } else if (result.errors) {
            return { success: false, error: result.errors.join(", ") };
        } else {
            return { success: false, error: result.message || "Ошибка сервера" };
        }
    } catch (error) {
        console.error("Ошибка отправки:", error);
        return { success: false, error: "Не удалось отправить сообщение. Проверьте соединение." };
    }
}

// ========== ИНИЦИАЛИЗАЦИЯ ==========
document.addEventListener("DOMContentLoaded", () => {
    // Загрузка работ
    loadWorksFromServer();
    
    // Фильтры
    const filterBtns = document.querySelectorAll(".filter-btn");
    filterBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            filterBtns.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            currentFilter = btn.dataset.filter;
            renderGallery();
        });
    });
    
    // Форма обратной связи
    const form = document.getElementById("feedback-form");
    const formMessage = document.getElementById("form-message");
    
    if (form) {
        form.addEventListener("submit", async (e) => {
            e.preventDefault();
            const name = document.getElementById("name").value;
            const email = document.getElementById("email").value;
            const message = document.getElementById("message").value;
            
            const result = await sendMessage(name, email, message);
            
            if (formMessage) {
                if (result.success) {
                    formMessage.textContent = "✅ Сообщение отправлено!";
                    formMessage.className = "form-message success";
                    form.reset();
                    setTimeout(() => {
                        formMessage.textContent = "";
                        formMessage.className = "form-message";
                    }, 3000);
                } else {
                    formMessage.textContent = `❌ ${result.error}`;
                    formMessage.className = "form-message error";
                    setTimeout(() => {
                        if (formMessage.textContent === `❌ ${result.error}`) {
                            formMessage.textContent = "";
                            formMessage.className = "form-message";
                        }
                    }, 5000);
                }
            }
        });
    }
    
    // Модальное окно
    const modal = document.getElementById("modal");
    const closeBtn = document.querySelector(".close-modal");
    const prevBtn = document.getElementById("prev-btn");
    const nextBtn = document.getElementById("next-btn");
    
    if (closeBtn) closeBtn.addEventListener("click", closeModal);
    if (prevBtn) prevBtn.addEventListener("click", prevImage);
    if (nextBtn) nextBtn.addEventListener("click", nextImage);
    
    if (modal) {
        modal.addEventListener("click", (e) => {
            if (e.target === modal) closeModal();
        });
    }
    
    // Закрытие модалки по Escape
    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
            closeModal();
        }
        if (e.key === "ArrowRight" && !modal?.classList.contains("hidden")) {
            nextImage();
        }
        if (e.key === "ArrowLeft" && !modal?.classList.contains("hidden")) {
            prevImage();
        }
    });
    
    // Мобильное меню
    const mobileBtn = document.querySelector(".mobile-menu-btn");
    const nav = document.querySelector("nav");
    if (mobileBtn && nav) {
        mobileBtn.addEventListener("click", () => {
            nav.classList.toggle("show");
        });
    }
});